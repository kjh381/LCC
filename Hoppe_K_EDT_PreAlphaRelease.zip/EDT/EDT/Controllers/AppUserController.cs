﻿using EDT.AppUserClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;

namespace EDT.Controllers
{
    public class AppUserController : Controller
    {
        //
        // GET: /AppUser/
        public AppUser CurrentUser
        {
            get
            {
                return new AppUser(this.User as ClaimsPrincipal);
            }
        }

	}

}