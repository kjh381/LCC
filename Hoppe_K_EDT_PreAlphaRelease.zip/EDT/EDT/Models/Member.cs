﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDT.Models
{
    public class Member
    {
        public int MemberID { get; set; }
        public bool Admin { get; set; }
        public string DisplayName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set;}
        public DateTime JoinDate { get; set; }
        public DateTime LastActive { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    
    }
}