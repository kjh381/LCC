﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CommunityPage.Controllers
{
    public class MapController : Controller
    {
        //
        // GET: /Map/
        public ActionResult Index()
        {
            //return Content("This is the map controller");
            ViewBag.MapURL = "https://www.google.com/maps/place/Eugene,+OR/@44.0592871,-123.1392894,13z/data=!4m2!3m1!1s0x54c119b0ac501919:0x57ec61894a43894d";

            return View();
        }
	}
}