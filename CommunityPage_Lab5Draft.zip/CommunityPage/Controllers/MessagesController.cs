﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CommunityPage.Models;

namespace CommunityPage.Models
{
    public class MessagesController : Controller
    {
        private ForumDBContext db = new ForumDBContext();

        // GET: /Messages/
        public ActionResult Index()
        {
            return View(GetTopicsAndMessages(null));
            //return View(GetTopicsAndMessages(1));
        }

        // GET: /Messages/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

        // GET: /Messages/Create
        public ActionResult Create()
        {
            ViewBag.MemberNames = new SelectList(db.Members.OrderBy(m => m.Name), "MemberID", "Name");
            return View();
        }

        // POST: /Messages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="MemberID,Subject,Body,Date,Author,TopicItem")] MessageVM message, int MemberNames)
        {
            Topic topic = new Topic();

            Member member = (from m in db.Members
                            where m.MemberID == MemberNames
                            select m).FirstOrDefault();

            //Allows for new topic creation
            if (ModelState.IsValid)
            {
                topic = (from t in db.Topics
                        where t.Title == message.TopicItem.Title
                        select t).FirstOrDefault();

                if (topic == null)
                {
                    Topic newTopic = new Topic
                    {
                        Title = message.TopicItem.Title,
                        Date = message.Date,

                        MemberID = (from m in db.Members
                               where m.Name == message.Author
                               select m.MemberID).FirstOrDefault()
                    };
                    db.Topics.Add(newTopic);
                    db.SaveChanges();

                    topic = newTopic;
                }

               /* int memID = (from m in db.Members
                               where m.Name == message.Author
                               select m.MemberID).FirstOrDefault();
                */

                Message newMessage = new Message
                {
                    TopicID = topic.TopicID,
                    Subject = message.Subject,
                    Body = message.Body,
                    Author = member.Name,
                    Date = message.Date,
                    MemberID = member.MemberID
                };

                db.Messages.Add(newMessage);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(message);
        }

        // GET: /Messages/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }

            ViewBag.MemberNames = new SelectList(db.Members.OrderBy(m => m.Name), "MemberID", "Name");
            return View(message);
        }

        // POST: /Messages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MessageID,TopicID,MemberID,Subject,Body,Date,Author")] Message message, int MemberNames)
        {
            Member member = (from m in db.Members
                             where m.MemberID == MemberNames
                             select m).FirstOrDefault();

            message.Author = member.Name;

            if (ModelState.IsValid)
            {
                db.Entry(message).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(message);
        }

        // GET: /Messages/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Message message = db.Messages.Find(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

        // POST: /Messages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Message message = db.Messages.Find(id);
            db.Messages.Remove(message);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(string searchTerm) 
        { 
            List<MessageVM> messageList = new List<MessageVM>();

            var searchResults = (from m in db.Messages
                                where m.Subject.Contains(searchTerm) || m.Body.Contains(searchTerm)
                                select m).Distinct();

            foreach (Message m in searchResults)
            {

                Topic topic = (from t in db.Topics
                               where m.TopicID == t.TopicID
                               select t).FirstOrDefault();

                var mess = new MessageVM();
                mess.MessageID = m.MessageID;
                mess.Date = m.Date;
                mess.Subject = m.Subject;
                mess.Author = m.Author;
                //mess.TopicItem.Title = m.TopicID.ToString();
                //mess.TopicItem.Title = topic.Title;
                mess.TopicItem = topic;

                messageList.Add(mess);
            
            }
            
            return View("Index", messageList);
        }


        public List<MessageVM> GetTopicsAndMessages(int? MemID)
        {
            var messageList = new List<MessageVM>();

            if (MemID != null)
            {
                var messages = from m in db.Messages
                               join t in db.Topics on m.MemberID equals t.MemberID
                               where m.MemberID == MemID
                               select m;

                foreach(Message m in messages)
                {
                    Topic topic = (from t in db.Topics.Include("messages")
                                 select t).FirstOrDefault();


                    var mess = new MessageVM();
                    mess.MessageID = m.MessageID;
                    mess.Date = m.Date;
                    mess.Subject = m.Subject;
                    mess.Author = m.Author;
                    mess.TopicItem = topic;
                    messageList.Add(mess);
                }

            }
            else
            {
                var messages = from m in db.Messages
                               join t in db.Topics on m.TopicID equals t.TopicID
                               orderby t.Title
                               select m;

                foreach (Message m in messages)
                {
                    Topic topic = (from t in db.Topics
                                   where m.TopicID == t.TopicID
                                   select t).FirstOrDefault();

                    var mess = new MessageVM();
                    mess.MessageID = m.MessageID;
                    mess.Date = m.Date;
                    mess.Subject = m.Subject;
                    mess.Author = m.Author;
                    //mess.TopicItem.Title = m.TopicID.ToString();
                    //mess.TopicItem.Title = topic.Title;
                    mess.TopicItem = topic;
                    messageList.Add(mess);
                }

            }


            return messageList;
        }
    }
}
