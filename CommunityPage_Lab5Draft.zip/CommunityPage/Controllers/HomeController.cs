﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;


namespace CommunityPage.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            DateTime now = DateTime.Now;
            ViewBag.currentTime = now;

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "About page - Info about company";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Insert contact info here";

            return View();
        }

        public ActionResult History()
        {
            ViewBag.Message = "Company history page";

            return View();
        }
    }
}