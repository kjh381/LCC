﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Message
    {
        public int MessageID { get; set; }
        public int TopicID { get; set; }
        public int MemberID { get; set; }
        public string Author { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        [MaxLength(500)]
        public string Body { get; set; }

        [Required]
        //Worst reg ex ever...
        [RegularExpression(".*")]
        public DateTime Date { get; set; }

    }
}