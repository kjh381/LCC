﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Member
    {
        public int MemberID {get; set;}
        public string Email { get; set; }
        public string Name { get; set; }

      /*  List<Message> userMessages = new List<Message>();
        public List<Message> Messages
        {
            get { return userMessages; }
        }

        List<Topic> userTopics = new List<Topic>();
        public List<Topic> Topics
        {
            get { return userTopics; }
        }
        */
    }
}