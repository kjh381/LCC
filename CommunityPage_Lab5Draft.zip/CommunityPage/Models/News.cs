﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class News
    {
        public string Title { get; set; }
        public string Story { get; set; }
        public string Source { get; set; }


        public News() { }

        public News(string newTitle, string newStory, string newsSource) {

            this.Title = newTitle;
            this.Story = newStory;
            this.Source = newsSource;
        }


    }
}