﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class MessageVM
    {
        public int MessageID { get; set; }
        public DateTime Date { get; set; }
        public string Author { get; set; }
        public string Subject { get; set; }
        
        private Topic topic = new Topic();
        public Topic TopicItem { get { return topic; } set { topic = value; } }

        public string Body { get; set; }

    }
}