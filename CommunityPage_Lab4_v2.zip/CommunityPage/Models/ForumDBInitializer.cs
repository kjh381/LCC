﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class ForumDBInitializer : DropCreateDatabaseAlways<ForumDBContext>
    {
        protected override void Seed(ForumDBContext context)
        {

            Member mem1 = new Member { MemberID = 1, Email = "hi@testing.com", Name = "Kyle" };
            Member mem2 = new Member { MemberID = 2, Email = "hello@stilltesting.com", Name = "Bob" };

            Message mess1 = new Message { MessageID = 0, MemberID = 1, TopicID = 0, Author = "Kyle", Subject = "Homework", Body = "Did you read the assignment?", Date = new DateTime(2015, 5, 25) };
            Message mess2 = new Message { MessageID = 1, MemberID = 2, TopicID = 0, Author = "Bob", Subject = "Homework", Body = "Skimmed it...I should read it again", Date = new DateTime(2015, 5, 25) };
            Message mess3 = new Message { MessageID = 2, MemberID = 1, TopicID = 0, Author = "Kyle", Subject = "Homework", Body = "Same yo", Date = new DateTime(2015, 5, 25) };
            Message mess4 = new Message { MessageID = 3, MemberID = 1, TopicID = 1, Author = "Kyle", Subject = "WorkWork", Body = "ZugZug", Date = new DateTime(2016, 1, 23) };

            Topic testTopic = new Topic { Title = "MVC Framework", TopicID = 0, Date = new DateTime(2015, 11, 23), MemberID=1 };
            Topic testTopic2 = new Topic { Title = "SomethingSomething", TopicID = 1, Date = new DateTime(2016, 1, 15), MemberID=2 };

            context.Members.Add(mem1);
            context.Members.Add(mem2);

            context.Messages.Add(mess1);
            context.Messages.Add(mess2);
            context.Messages.Add(mess3);
            context.Messages.Add(mess4);

            context.Topics.Add(testTopic);
            context.Topics.Add(testTopic2);


            base.Seed(context);

        }
    }
}