﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Message
    {
        public int MessageID { get; set; }
        public int TopicID { get; set; }
        public int MemberID { get; set; }
        public string Author { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime Date { get; set; }

    }
}