﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDT.Models
{
    public class Image
    {
        public int ImageID { get; set; }
        public int LocationID { get; set; }
        public int AddedBy { get; set; }
        public string ImageName { get; set; }
        public string Caption { get; set; }
        public bool Display { get; set; }

    }
}