﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Message
    {
        public int MessageID { get; set; }
        public int TopicID { get; set; }
        public string MemberID { get; set; }
        public string Author { get; set; }
        [Required]
        [MinLength(3)]
        [MaxLength(30)]
        public string Subject { get; set; }
        [Required]
        [MaxLength(500)]
        public string Body { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yy}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }

    }
}