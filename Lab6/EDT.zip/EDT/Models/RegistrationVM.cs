﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;

namespace EDT.Models
{
    public class RegistrationVM
    {        
        [Required] 
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string Phone { get; set; }
        public string DisplayName { get; set; }


        bool superAdmin = false;
        
        public bool SuperAdmin
        {
            get { return this.superAdmin; }
            set { this.superAdmin = value; }
        }

        bool admin = false;
        
        public bool Admin
        {
           get {return this.admin;}
           set {this.admin = value;}
        }
        

        public string FirstName { get; set; }

        public string LastName { get; set; }
        

        DateTime joined = DateTime.Today;
        public DateTime JoinDate {
            get { return this.joined; }
            set { this.joined = value; }
        }

        DateTime active = DateTime.Today;
        
        public DateTime LastActive {
            get { return this.active;}
            set { this.active = value;}
        }

    }
}