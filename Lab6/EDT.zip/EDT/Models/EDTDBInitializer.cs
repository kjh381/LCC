﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EDT.Models
{
    public class EDTDBInitializer: DropCreateDatabaseAlways<EDTDBContext>
    {

        protected override void Seed(EDTDBContext context)
        {
            Member tester = new Member {Id = "0", Admin = false, UserName = "NumbaOneTester", FirstName="Joe", LastName="Dirt", Email="test@testers.com", PhoneNumber="(541)123-1234", JoinDate= new DateTime(2016,5,25), 
            LastActive= new DateTime(2016,5,25)};
            
            context.Users.Add(tester);
            //Password = "abc123",

            Advertisment ad1 = new Advertisment { AdvertismentID = 0, Clicks = 0, Code = "string of code here", StartDate = new DateTime(2016, 2, 20), ExpDate = new DateTime(2017, 1, 1) };
            context.Advertisments.Add(ad1);

            Event ev1 = new Event { EventID = 0, Approved = false, Date = new DateTime(2016, 3, 1), Description = "Here is a test event description", Location = "Downtown Portland, good luck finding us", MemberID = 0, Time = new TimeSpan(12, 30, 00), Title = "Hiding in Downtown P-town" };
            context.Events.Add(ev1);

            Image image1 = new Image { ImageID = 0, AddedBy = 0, ImageName = "imagename.jpg", LocationID = 0, Display = false, Caption = "My New Image" };
            context.Images.Add(image1);

            Location loc1 = new Location
                            {
                                LocationID = 0,
                                Approved = true,
                                AddedBy = 0,
                                Category = "Hiking",
                                Description = "A place about an hour away",
                                Name = "Whitaker Creek",
                                Difficulty = 4,
                                Distance = 40,
                                DriveTime = new TimeSpan(0,45,0),
                                Duration = new TimeSpan(1,30,0),
                                Fees = 0,
                                Length = 2
                            };
            context.Locations.Add(loc1);

            Location loc2 = new Location
            {
                LocationID = 1,
                Approved = true,
                AddedBy = 0,
                Category = "Hiking",
                Description = "Duplicate to test search",
                Name = "Different Name",
                Difficulty = 4,
                Distance = 40,
                DriveTime = new TimeSpan(0, 45, 0),
                Duration = new TimeSpan(1, 30, 0),
                Fees = 0,
                Length = 2
            };
            context.Locations.Add(loc2);

            Comment comment1 = new Comment { CommentID = 0, UserID = 0, LocationID = 0, Date = new DateTime(2015, 8, 16), Body = "Watch for bears and salmon" };
            context.Comments.Add(comment1);

        }
    }
}