﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDT.Models
{
    public class Member : IdentityUser
    {
        //public int MemberID { get; set; }
        //public void dummy() { this.
        public bool SuperAdmin { get; set; }
        public bool Admin { get; set; }
        public string DisplayName { get; set; }
        //public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set;}
        public DateTime JoinDate { get; set; }
        public DateTime LastActive { get; set; }
        //public string Email { get; set; }
        public string Phone { get; set; }
    
    }
}