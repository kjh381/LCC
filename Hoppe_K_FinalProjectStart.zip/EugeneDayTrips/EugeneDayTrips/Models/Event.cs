﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EugeneDayTrips.Models
{
    public class Event
    {
        public int EventID { get; set; }
        public int UserID { get; set; }
        public bool Approved { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
    }
}