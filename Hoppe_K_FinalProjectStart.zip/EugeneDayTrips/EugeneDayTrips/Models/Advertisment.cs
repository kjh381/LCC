﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EugeneDayTrips.Models
{
    public class Advertisment
    {
        public int AdID { get; set; }
        public int Clicks { get; set; }
        public string Code{get;set;}
        public DateTime StartDate { get; set; }
        public DateTime ExpDate { get; set; }
    }
}