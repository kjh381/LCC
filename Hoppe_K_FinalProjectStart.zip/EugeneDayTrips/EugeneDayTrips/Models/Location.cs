﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EugeneDayTrips.Models
{
    public class Location
    {
        public int LocationID { get; set; }
        public bool Approved { get; set; }

        //UserID that added the location
        public int AddedBy { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }

        //1-10? pair with values in a drop down
        public int Difficulty { get; set; }
        public double Length { get; set; }
        public TimeSpan Duration { get; set; }
        public double Distance { get; set; }
        public TimeSpan DriveTime { get; set; }
        public double Fees { get; set; }

    }
}