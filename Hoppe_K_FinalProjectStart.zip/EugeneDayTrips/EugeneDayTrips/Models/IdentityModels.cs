﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;

namespace EugeneDayTrips.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        public int UserID {get;set;}
        public bool Admin { get; set; }
        public string DisplayName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set;}
        public DateTime JoinDate { get; set; }
        public DateTime LastActive { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection")
        {
        }
    }
}