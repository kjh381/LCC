﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EugeneDayTrips.Models
{
    public class Comment
    {
        public int CommentID { get; set; }
        public int UserID { get; set; }
        public int LocationID { get; set; }
        public DateTime Date{ get; set;}
        public string Body { get; set; }

    }
}