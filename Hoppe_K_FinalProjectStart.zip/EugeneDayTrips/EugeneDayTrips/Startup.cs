﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EugeneDayTrips.Startup))]
namespace EugeneDayTrips
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
