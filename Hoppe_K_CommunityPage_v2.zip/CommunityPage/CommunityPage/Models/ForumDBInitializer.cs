﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class ForumDBInitializer : DropCreateDatabaseAlways<ForumDBContext>
    {
        protected override void Seed(ForumDBContext context)
        {

            Member mem1 = new Member { MemberID = 1, Email = "hi@testing.com", Name = "Kyle" };
            Member mem2 = new Member { MemberID = 2, Email = "hello@stilltesting.com", Name = "John" };

            Message mess1 = new Message{ MessageID=0, To="Kyle", From="John", Subject="Homework", Body="Did you read the assignment?", Date=new DateTime(2015,5,25)};
            Message mess2 = new Message { MessageID = 1, To = "John", From = "Kyle", Subject = "Homework", Body = "Skimmed it...I should read it again", Date = new DateTime(2015, 5, 25)};
            Message mess3 = new Message { MessageID = 2, To = "Kyle", From = "John", Subject = "Homework", Body = "Same yo", Date = new DateTime(2015, 5, 25) };
            Message mess4 = new Message { MessageID = 3, To = "Kyle", From = "Orc", Subject = "WorkWork", Body = "ZugZug", Date = new DateTime(2016, 1, 23) };

            Topic testTopic = new Topic { Title="MVC Framework", TopicID=0, CreatorID=1 };

            context.Members.Add(mem1);
            context.Members.Add(mem2);

            context.Messages.Add(mess1);
            context.Messages.Add(mess2);
            context.Messages.Add(mess3);
            context.Messages.Add(mess4);

            context.Topics.Add(testTopic);


            base.Seed(context);

        }
    }
}