﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Topic
    {
        //new List<Message> TopicMessages = new List<Message>();
        public string Title { get; set; }
        public int TopicID { get; set; }
        public int CreatorID { get; set; }

    }
}