﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CommunityPage.Models;

namespace CommunityPage.Controllers
{
    public class NewsController : Controller
    {
        //
        // GET: /News/
        public ActionResult Index()
        {
            List<News> newsList = new List<News>();
            
            newsList.Add(new News("Test1", "This is a test story about some news", "CNN"));
            newsList.Add(new News("Test2", "Get yur news right hear!", "NBC"));
            newsList.Add(new News("Test3", "Oh hi, I have some news...", "ABC"));
            newsList.Add(new News("Test4", "Yup, more news here", "Facebook, the most reliable of sources"));                       

            return View(newsList);
        }

        public ActionResult Archive()
        {
            List<News> newsList = new List<News>();

            newsList.Add(new News("Test1", "This is a test story about some news", "CNN"));
            newsList.Add(new News("Test2", "Get yur news right hear!", "NBC"));
            newsList.Add(new News("Test3", "Oh hi, I have some news...", "ABC"));
            newsList.Add(new News("Test4", "Yup, more news here", "Facebook, the most reliable of sources"));

            return View(newsList);
        }

    }
}