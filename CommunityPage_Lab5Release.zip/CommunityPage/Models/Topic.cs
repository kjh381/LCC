﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CommunityPage.Models
{
    public class Topic
    {
        List<Message> topicMessages = new List<Message>();

        
        [Required]
        public string Title { get; set; }
        public int TopicID { get; set; }
        public DateTime Date { get; set; }
        public int MemberID { get; set; }

        public List<Message> Messages{
            get { return topicMessages; }
        }

    }
}